#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Générateur du classeur "Suivi de Charge d'Entraînement - Effectif Sportif"
Produit un fichier .xlsx complet : dashboard, fiches athlètes, calculs
CT / charge aiguë / charge chronique / ACWR / fatigue, graphiques,
mise en forme conditionnelle, validations, protections, mise en page.

Usage:
    python3 generate.py [nb_athletes] [output_path]
"""
import sys
import datetime as dt
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, NamedStyle
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.chart import LineChart, Reference, Series
from openpyxl.chart.axis import DateAxis
from openpyxl.worksheet.table import Table, TableStyleInfo
from openpyxl.utils.cell import quote_sheetname
from openpyxl.workbook.defined_name import DefinedName
from openpyxl.worksheet.page import PageMargins

# ---------------------------------------------------------------------------
# PARAMETRES GLOBAUX
# ---------------------------------------------------------------------------
NB_ATHLETES = int(sys.argv[1]) if len(sys.argv) > 1 else 30
OUTPUT = sys.argv[2] if len(sys.argv) > 2 else "Suivi_Charge_Effectif.xlsx"

DATE_DEBUT = dt.date.today()
DATE_FIN = dt.date(2026, 12, 31)
if DATE_FIN < DATE_DEBUT:
    DATE_FIN = DATE_DEBUT  # garde-fou

NB_JOURS = (DATE_FIN - DATE_DEBUT).days + 1
HEADER_ROW = 5          # ligne d'en-tête du tableau journalier
FIRST_DATA_ROW = 6
LAST_DATA_ROW = FIRST_DATA_ROW + NB_JOURS - 1

TYPES_SEANCE = [
    "Repos", "Match", "Match amical", "Technique", "Tactique",
    "Renforcement", "Force", "Puissance", "Explosivité", "Vitesse",
    "VMA", "HIIT", "Endurance", "Récupération", "Mobilité",
    "Prévention", "Réathlétisation", "Autre",
]

# --- Palette -----------------------------------------------------------
NAVY = "1F3864"
NAVY_LIGHT = "2E4E8C"
GREY_LIGHT = "F2F2F2"
GREY_MID = "D9D9D9"
WHITE = "FFFFFF"
GREEN = "C6EFCE"
GREEN_TXT = "006100"
ORANGE = "FFEB9C"
ORANGE_TXT = "9C6500"
RED = "FFC7CE"
RED_TXT = "9C0006"
FONT_NAME = "Calibri"

thin = Side(style="thin", color="BFBFBF")
THIN_BORDER = Border(left=thin, right=thin, top=thin, bottom=thin)

def f_title(size=14, color=WHITE):
    return Font(name=FONT_NAME, size=size, bold=True, color=color)

def f_header():
    return Font(name=FONT_NAME, size=10, bold=True, color=WHITE)

def f_normal(bold=False, size=10, color="000000", italic=False):
    return Font(name=FONT_NAME, size=size, bold=bold, color=color, italic=italic)

def fill(color):
    return PatternFill(start_color=color, end_color=color, fill_type="solid")

CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT = Alignment(horizontal="left", vertical="center")

wb = Workbook()
wb.remove(wb.active)

# ---------------------------------------------------------------------------
# FEUILLE LISTES
# ---------------------------------------------------------------------------
ws_listes = wb.create_sheet("Listes")
ws_listes.sheet_state = "hidden"
ws_listes["A1"] = "Type de séance"
ws_listes["A1"].font = f_normal(bold=True)
for i, t in enumerate(TYPES_SEANCE, start=2):
    ws_listes.cell(row=i, column=1, value=t)
last_type_row = 1 + len(TYPES_SEANCE)

ws_listes["C1"] = "Seuils ACWR"
ws_listes["C1"].font = f_normal(bold=True)
seuils = [
    ("Rouge bas", 0, 0.5), ("Orange bas", 0.5, 0.8),
    ("Vert", 0.8, 1.3), ("Orange haut", 1.3, 1.5), ("Rouge haut", 1.5, 99),
]
for i, (label, lo, hi) in enumerate(seuils, start=2):
    ws_listes.cell(row=i, column=3, value=label)
    ws_listes.cell(row=i, column=4, value=lo)
    ws_listes.cell(row=i, column=5, value=hi)

wb.defined_names["TypeSeanceListe"] = DefinedName(
    "TypeSeanceListe", attr_text=f"Listes!$A$2:$A${last_type_row}"
)

# noms des feuilles athlètes
ATHLETE_SHEETS = [f"Athlète {i}" for i in range(1, NB_ATHLETES + 1)]

print(f"Génération pour {NB_ATHLETES} athlètes, {NB_JOURS} jours "
      f"({DATE_DEBUT} -> {DATE_FIN}), lignes {FIRST_DATA_ROW}-{LAST_DATA_ROW}")

# ---------------------------------------------------------------------------
# COLONNES FICHE ATHLETE
# ---------------------------------------------------------------------------
COLS = ["Date", "Jour", "Semaine", "Mois", "Année", "Type de séance", "RPE",
        "Durée (h)", "CT", "Charge aiguë", "Charge chronique", "ACWR",
        "Fatigue", "Commentaires"]
COL_LETTERS = {name: get_column_letter(i + 1) for i, name in enumerate(COLS)}
# A=Date B=Jour C=Semaine D=Mois E=Année F=Type G=RPE H=Durée I=CT
# J=Charge aiguë K=Charge chronique L=ACWR M=Fatigue N=Commentaires

def nav_button(ws, row, col, label, target_sheet, w=None):
    c = ws.cell(row=row, column=col, value=label)
    c.font = Font(name=FONT_NAME, size=10, bold=True, color=WHITE)
    c.fill = fill(NAVY_LIGHT)
    c.alignment = CENTER
    c.border = THIN_BORDER
    c.hyperlink = f"#{quote_sheetname(target_sheet)}!A1"
    return c

def build_athlete_sheet(wb, idx, name):
    sheet_name = f"Athlète {idx}"
    ws = wb.create_sheet(sheet_name)
    ws.sheet_view.showGridLines = False

    # --- Barre de navigation -------------------------------------------------
    nav_button(ws, 1, 1, "🏠 Dashboard", "Dashboard")
    prev_target = f"Athlète {idx-1}" if idx > 1 else sheet_name
    next_target = f"Athlète {idx+1}" if idx < NB_ATHLETES else sheet_name
    nav_button(ws, 1, 2, "◀ Précédent", prev_target)
    nav_button(ws, 1, 3, "Suivant ▶", next_target)
    ws.row_dimensions[1].height = 20

    # --- Titre -----------------------------------------------------------
    ws.merge_cells("A3:E3")
    t = ws["A3"]
    t.value = f"FICHE ATHLÈTE {idx}"
    t.font = f_title(16, NAVY)
    t.alignment = LEFT

    ws["F3"] = "Nom du joueur :"
    ws["F3"].font = f_normal(bold=True)
    ws["F3"].alignment = Alignment(horizontal="right", vertical="center")
    ws.merge_cells("G3:I3")
    nom_cell = ws["G3"]
    nom_cell.value = name
    nom_cell.font = f_normal(bold=True, size=11, color=NAVY)
    nom_cell.fill = fill(GREY_LIGHT)
    nom_cell.border = THIN_BORDER
    nom_cell.alignment = CENTER

    # --- En-tête tableau ---------------------------------------------------
    for i, col_name in enumerate(COLS, start=1):
        c = ws.cell(row=HEADER_ROW, column=i, value=col_name)
        c.font = f_header()
        c.fill = fill(NAVY)
        c.alignment = CENTER
        c.border = THIN_BORDER
    ws.row_dimensions[HEADER_ROW].height = 30

    widths = [12, 11, 9, 11, 8, 16, 7, 9, 9, 12, 13, 8, 9, 26]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    # --- Lignes journalières -------------------------------------------------
    current = DATE_DEBUT
    for r in range(FIRST_DATA_ROW, LAST_DATA_ROW + 1):
        ws.cell(row=r, column=1, value=current)  # Date (valeur réelle)
        ws.cell(row=r, column=1).number_format = "dd/mm/yyyy"
        ws.cell(row=r, column=2, value=f"=TEXT(A{r},\"dddd\")")
        ws.cell(row=r, column=3, value=f"=WEEKNUM(A{r},2)")
        ws.cell(row=r, column=4, value=f"=TEXT(A{r},\"mmmm\")")
        ws.cell(row=r, column=5, value=f"=YEAR(A{r})")
        ws.cell(row=r, column=6, value=None)   # Type de séance (saisie)
        ws.cell(row=r, column=7, value=None)   # RPE (saisie)
        ws.cell(row=r, column=8, value=None)   # Durée (saisie)
        ws.cell(row=r, column=9,
                value=f"=IF(OR(G{r}=\"\",H{r}=\"\"),0,G{r}*H{r})")  # CT
        acute_start = f"I${FIRST_DATA_ROW}" if r - 6 < FIRST_DATA_ROW else f"I{r-6}"
        ws.cell(row=r, column=10,
                value=f"=SUM({acute_start}:I{r})")  # Charge aiguë (7j)
        chronic_start = f"I${FIRST_DATA_ROW}" if r - 27 < FIRST_DATA_ROW else f"I{r-27}"
        ws.cell(row=r, column=11,
                value=f"=AVERAGE({chronic_start}:I{r})")  # Charge chronique (28j)
        ws.cell(row=r, column=12,
                value=f"=IF(K{r}=0,\"\",J{r}/K{r})")  # ACWR
        if r == FIRST_DATA_ROW:
            ws.cell(row=r, column=13, value=f"=MAX(0,0+(J{r}-K{r}))")
        else:
            ws.cell(row=r, column=13,
                    value=f"=MAX(0,M{r-1}+(J{r}-K{r}))")  # Fatigue
        ws.cell(row=r, column=14, value=None)  # Commentaires

        # format & bordures
        for col in range(1, 15):
            cell = ws.cell(row=r, column=col)
            cell.border = THIN_BORDER
            cell.font = f_normal(size=10)
            cell.alignment = CENTER if col not in (14,) else LEFT
        ws.cell(row=r, column=9).number_format = "0.0"
        ws.cell(row=r, column=10).number_format = "0.0"
        ws.cell(row=r, column=11).number_format = "0.0"
        ws.cell(row=r, column=12).number_format = "0.00"
        ws.cell(row=r, column=13).number_format = "0.0"
        # bande alternée (semaine paire / impaire) pour lisibilité
        if (r - FIRST_DATA_ROW) % 14 >= 7:
            for col in range(1, 15):
                ws.cell(row=r, column=col).fill = fill(GREY_LIGHT)
        current += dt.timedelta(days=1)

    # --- Table structurée ----------------------------------------------------
    tbl_ref = f"A{HEADER_ROW}:N{LAST_DATA_ROW}"
    table = Table(displayName=f"TblAthlete{idx}", ref=tbl_ref)
    table.tableStyleInfo = TableStyleInfo(
        name="TableStyleMedium2", showRowStripes=False,
        showFirstColumn=False, showLastColumn=False, showColumnStripes=False)
    ws.add_table(table)

    # --- Validation de données ------------------------------------------------
    dv_type = DataValidation(type="list", formula1="=TypeSeanceListe",
                              allow_blank=True, showDropDown=False)
    dv_type.error = "Sélectionner un type de séance dans la liste."
    dv_type.errorTitle = "Type de séance invalide"
    ws.add_data_validation(dv_type)
    dv_type.add(f"F{FIRST_DATA_ROW}:F{LAST_DATA_ROW}")

    dv_rpe = DataValidation(type="whole", operator="between", formula1=0, formula2=10,
                             allow_blank=True)
    dv_rpe.error = "RPE compris entre 0 et 10."
    dv_rpe.errorTitle = "RPE invalide"
    ws.add_data_validation(dv_rpe)
    dv_rpe.add(f"G{FIRST_DATA_ROW}:G{LAST_DATA_ROW}")

    dv_duree = DataValidation(type="decimal", operator="between", formula1=0, formula2=6,
                               allow_blank=True)
    dv_duree.error = "Durée en heures, entre 0 et 6."
    dv_duree.errorTitle = "Durée invalide"
    ws.add_data_validation(dv_duree)
    dv_duree.add(f"H{FIRST_DATA_ROW}:H{LAST_DATA_ROW}")

    # --- Mise en forme conditionnelle ACWR (colonne L) -------------------------
    rng = f"L{FIRST_DATA_ROW}:L{LAST_DATA_ROW}"
    ws.conditional_formatting.add(
        rng, FormulaRule(formula=[f"AND(L{FIRST_DATA_ROW}<>\"\",OR(L{FIRST_DATA_ROW}<0.5,L{FIRST_DATA_ROW}>1.5))"],
                          fill=fill(RED), font=Font(color=RED_TXT, bold=True)))
    ws.conditional_formatting.add(
        rng, FormulaRule(formula=[f"AND(L{FIRST_DATA_ROW}<>\"\",OR(AND(L{FIRST_DATA_ROW}>=0.5,L{FIRST_DATA_ROW}<0.8),AND(L{FIRST_DATA_ROW}>1.3,L{FIRST_DATA_ROW}<=1.5)))"],
                          fill=fill(ORANGE), font=Font(color=ORANGE_TXT, bold=True)))
    ws.conditional_formatting.add(
        rng, FormulaRule(formula=[f"AND(L{FIRST_DATA_ROW}<>\"\",L{FIRST_DATA_ROW}>=0.8,L{FIRST_DATA_ROW}<=1.3)"],
                          fill=fill(GREEN), font=Font(color=GREEN_TXT, bold=True)))

    # --- Graphiques ---------------------------------------------------------
    dates_ref = Reference(ws, min_col=1, min_row=FIRST_DATA_ROW, max_row=LAST_DATA_ROW)

    def make_chart(title, col, y_title, color):
        ch = LineChart()
        ch.title = title
        ch.style = 2
        ch.height = 7.5
        ch.width = 16
        ch.y_axis.title = y_title
        ch.x_axis.title = "Date"
        ch.x_axis.number_format = "dd/mm"
        ch.x_axis.majorTimeUnit = "days"
        data = Reference(ws, min_col=col, min_row=HEADER_ROW, max_row=LAST_DATA_ROW)
        ch.add_data(data, titles_from_data=True)
        ch.set_categories(dates_ref)
        s = ch.series[0]
        s.smooth = False
        s.graphicalProperties.line.width = 18000
        s.graphicalProperties.line.solidFill = color
        ch.legend = None
        return ch

    ch_ct = make_chart("Charge de Travail (CT)", 9, "CT", "2E4E8C")
    ch_acwr = make_chart("ACWR", 12, "ACWR", "C0504D")
    ch_fatigue = make_chart("Fatigue cumulée", 13, "Fatigue", "9BBB59")

    ws.add_chart(ch_ct, "P3")
    ws.add_chart(ch_acwr, "P19")
    ws.add_chart(ch_fatigue, "P35")

    # --- Protection -------------------------------------------------------
    for r in range(FIRST_DATA_ROW, LAST_DATA_ROW + 1):
        for col in range(1, 15):
            ws.cell(row=r, column=col).protection = ws.cell(row=r, column=col).protection.copy(locked=True)
        for col in (6, 7, 8, 14):  # Type, RPE, Durée, Commentaires -> déverrouillés
            ws.cell(row=r, column=col).protection = ws.cell(row=r, column=col).protection.copy(locked=False)
    nom_cell.protection = nom_cell.protection.copy(locked=False)
    ws.protection.sheet = True
    ws.protection.formatCells = False
    ws.protection.formatColumns = False
    ws.protection.formatRows = False

    # --- Mise en page / impression -----------------------------------------
    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.3, right=0.3, top=0.5, bottom=0.5,
                                   header=0.2, footer=0.2)
    ws.print_title_rows = f"{HEADER_ROW}:{HEADER_ROW}"
    ws.print_area = f"A1:N{LAST_DATA_ROW}"
    ws.oddHeader.center.text = f"Fiche Athlète {idx} - {name}"
    ws.oddFooter.left.text = "&D"
    ws.oddFooter.right.text = "Page &P / &N"
    ws.freeze_panes = f"A{FIRST_DATA_ROW}"
    ws.sheet_view.zoomScale = 90

    return ws

# ---------------------------------------------------------------------------
# FEUILLE PARAMETRES
# ---------------------------------------------------------------------------
def build_parametres(wb):
    ws = wb.create_sheet("Paramètres")
    ws.sheet_view.showGridLines = False
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 55

    ws.merge_cells("A1:C1")
    ws["A1"] = "PARAMÈTRES DE L'OUTIL"
    ws["A1"].font = f_title(16, NAVY)

    rows = [
        ("Nombre d'athlètes", NB_ATHLETES,
         "Nombre de fiches Athlète générées dans ce classeur."),
        ("Date de début de saison", DATE_DEBUT, "Aujourd'hui à la génération du fichier."),
        ("Date de fin de saison", DATE_FIN, "31 décembre 2026."),
        ("Fenêtre charge aiguë (jours)", 7, "Somme des CT sur 7 jours glissants."),
        ("Fenêtre charge chronique (jours)", 28, "Moyenne des CT sur 28 jours glissants."),
        ("Seuil ACWR vert - bas", 0.8, ""),
        ("Seuil ACWR vert - haut", 1.3, ""),
        ("Seuil ACWR orange - bas", 0.5, ""),
        ("Seuil ACWR orange - haut", 1.5, ""),
    ]
    r = 3
    ws.cell(row=r, column=1, value="Paramètre").font = f_header()
    ws.cell(row=r, column=1).fill = fill(NAVY)
    ws.cell(row=r, column=2, value="Valeur").font = f_header()
    ws.cell(row=r, column=2).fill = fill(NAVY)
    ws.cell(row=r, column=3, value="Commentaire").font = f_header()
    ws.cell(row=r, column=3).fill = fill(NAVY)
    r += 1
    for label, val, comment in rows:
        ws.cell(row=r, column=1, value=label).font = f_normal(bold=True)
        c = ws.cell(row=r, column=2, value=val)
        c.font = f_normal(color="1F3864")
        c.fill = fill(GREY_LIGHT)
        if isinstance(val, dt.date):
            c.number_format = "dd/mm/yyyy"
        ws.cell(row=r, column=3, value=comment).font = f_normal(italic=True, size=9)
        for col in range(1, 4):
            ws.cell(row=r, column=col).border = THIN_BORDER
        r += 1

    r += 2
    ws.merge_cells(f"A{r}:C{r}")
    ws.cell(row=r, column=1,
            value="Faire évoluer le nombre d'athlètes (20 / 30 / 40 / 50)").font = f_normal(bold=True, size=11, color=NAVY)
    r += 1
    note = ("Ce classeur est généré par un script Python (fourni séparément). "
            "Pour passer à 20, 40 ou 50 athlètes, relancer le script avec le "
            "paramètre souhaité : toutes les fiches, formules, graphiques, "
            "validations et le Dashboard sont reconstruits automatiquement, "
            "sans aucune formule à retoucher à la main.")
    ws.merge_cells(f"A{r}:C{r+3}")
    cell = ws.cell(row=r, column=1, value=note)
    cell.alignment = Alignment(wrap_text=True, vertical="top")
    cell.font = f_normal(size=10)
    r += 5

    ws.merge_cells(f"A{r}:C{r}")
    ws.cell(row=r, column=1, value="Légende des couleurs ACWR").font = f_normal(bold=True, size=11, color=NAVY)
    r += 1
    legend = [
        ("Vert", "0.8 ≤ ACWR ≤ 1.3", GREEN, GREEN_TXT),
        ("Orange", "0.5 ≤ ACWR < 0.8  ou  1.3 < ACWR ≤ 1.5", ORANGE, ORANGE_TXT),
        ("Rouge", "ACWR < 0.5  ou  ACWR > 1.5", RED, RED_TXT),
    ]
    r += 1
    ws.merge_cells(f"A{r}:C{r+2}")
    warn = ws.cell(row=r, column=1, value=(
        "⚠ Remarque méthodologique : conformément au cahier des charges, la Charge "
        "aiguë est une SOMME sur 7 jours alors que la Charge chronique est une MOYENNE "
        "sur 28 jours. L'ACWR obtenu (somme/moyenne) est donc environ 7x plus élevé que "
        "l'ACWR classique de la littérature sportive (moyenne/moyenne). Les seuils "
        "0.8/1.3/1.5 ont été conservés tels que demandés. Pour un ACWR 'classique', "
        "modifier la formule de Charge aiguë en AVERAGE(...) au lieu de SUM(...)."))
    warn.alignment = Alignment(wrap_text=True, vertical="top")
    warn.font = f_normal(size=9, italic=True, color="9C6500")
    r += 4

    for label, desc, bg, txt in legend:
        c1 = ws.cell(row=r, column=1, value=label)
        c1.fill = fill(bg)
        c1.font = Font(name=FONT_NAME, bold=True, color=txt)
        c1.alignment = CENTER
        c1.border = THIN_BORDER
        ws.cell(row=r, column=2, value=desc).font = f_normal(size=10)
        ws.merge_cells(f"B{r}:C{r}")
        r += 1

    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    return ws

# ---------------------------------------------------------------------------
# FEUILLE BASE DE DONNEES (moyennes quotidiennes du groupe)
# ---------------------------------------------------------------------------
def build_base_donnees(wb):
    ws = wb.create_sheet("Base de données")
    ws.sheet_view.showGridLines = False
    ws["A1"] = "BASE DE DONNÉES - MOYENNES QUOTIDIENNES DU GROUPE"
    ws["A1"].font = f_title(13, NAVY)
    ws.merge_cells("A1:D1")

    headers = ["Date", "CT moyenne du groupe", "Fatigue moyenne du groupe", "ACWR moyen du groupe"]
    for i, h in enumerate(headers, start=1):
        c = ws.cell(row=3, column=i, value=h)
        c.font = f_header()
        c.fill = fill(NAVY)
        c.alignment = CENTER
        c.border = THIN_BORDER
    ws.column_dimensions["A"].width = 12
    for col in "BCD":
        ws.column_dimensions[col].width = 20

    ct_refs = ",".join(f"'{s}'!I{{r}}" for s in ATHLETE_SHEETS)
    fa_refs = ",".join(f"'{s}'!M{{r}}" for s in ATHLETE_SHEETS)
    acwr_refs = ",".join(f"'{s}'!L{{r}}" for s in ATHLETE_SHEETS)

    start = 4
    for offset, r in enumerate(range(FIRST_DATA_ROW, LAST_DATA_ROW + 1)):
        row = start + offset
        ws.cell(row=row, column=1, value=f"='{ATHLETE_SHEETS[0]}'!A{r}")
        ws.cell(row=row, column=1).number_format = "dd/mm/yyyy"
        ws.cell(row=row, column=2, value=f"=AVERAGE({ct_refs.format(r=r)})")
        ws.cell(row=row, column=3, value=f"=AVERAGE({fa_refs.format(r=r)})")
        ws.cell(row=row, column=4,
                value=f"=IFERROR(AVERAGE({acwr_refs.format(r=r)}),\"\")")
        for col in range(1, 5):
            ws.cell(row=row, column=col).border = THIN_BORDER
            ws.cell(row=row, column=col).font = f_normal(size=9)
            ws.cell(row=row, column=col).alignment = CENTER
        ws.cell(row=row, column=2).number_format = "0.0"
        ws.cell(row=row, column=3).number_format = "0.0"
        ws.cell(row=row, column=4).number_format = "0.00"

    ws.freeze_panes = "A4"
    ws.page_setup.orientation = "portrait"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.5, right=0.5, top=0.5, bottom=0.5, header=0.2, footer=0.2)
    ws.print_title_rows = "3:3"
    ws.print_area = f"A1:D{start + NB_JOURS - 1}"
    ws.oddHeader.center.text = "Base de données - moyennes du groupe"
    ws.oddFooter.left.text = "&D"
    ws.oddFooter.right.text = "Page &P / &N"
    return ws, start

# ---------------------------------------------------------------------------
# FEUILLE DASHBOARD
# ---------------------------------------------------------------------------
def build_dashboard(wb, names, base_start_row):
    ws = wb.create_sheet("Dashboard")
    ws.sheet_view.showGridLines = False
    ws.sheet_properties.tabColor = NAVY

    ws.merge_cells("A1:N2")
    t = ws["A1"]
    t.value = "DASHBOARD - SUIVI DE LA CHARGE D'ENTRAÎNEMENT DE L'EFFECTIF"
    t.font = f_title(18, WHITE)
    t.alignment = CENTER
    for col in range(1, 15):
        ws.cell(row=1, column=col).fill = fill(NAVY)
        ws.cell(row=2, column=col).fill = fill(NAVY)
    ws.row_dimensions[1].height = 22
    ws.row_dimensions[2].height = 10

    ws.merge_cells("A3:N3")
    sub = ws["A3"]
    sub.value = ('=CONCATENATE("Saison : ",TEXT(Paramètres!B4,"dd/mm/yyyy")," au ",'
                 'TEXT(Paramètres!B5,"dd/mm/yyyy")," — Aujourd\'hui : ",TEXT(TODAY(),"dddd dd mmmm yyyy"))')
    sub.font = f_normal(italic=True, size=10, color="595959")
    sub.alignment = CENTER

    # -------- Formules de synthèse (par athlète, ligne du jour courant) -----
    synth_header_row = 25
    synth_start = synth_header_row + 1
    synth_end = synth_start + NB_ATHLETES - 1

    ws.cell(row=synth_header_row, column=1, value="N°")
    ws.cell(row=synth_header_row, column=2, value="Athlète")
    ws.cell(row=synth_header_row, column=3, value="Charge aiguë (7j)")
    ws.cell(row=synth_header_row, column=4, value="Charge chronique (28j)")
    ws.cell(row=synth_header_row, column=5, value="ACWR")
    ws.cell(row=synth_header_row, column=6, value="Fatigue")
    ws.cell(row=synth_header_row, column=7, value="Alerte")
    ws.cell(row=synth_header_row, column=8, value="Fiche")
    for col in range(1, 9):
        c = ws.cell(row=synth_header_row, column=col)
        c.font = f_header()
        c.fill = fill(NAVY)
        c.alignment = CENTER
        c.border = THIN_BORDER

    for i, sheet in enumerate(ATHLETE_SHEETS, start=1):
        r = synth_start + i - 1
        S = f"'{sheet}'"
        match_formula = f"MATCH(TODAY(),{S}!$A${FIRST_DATA_ROW}:$A${LAST_DATA_ROW},0)"
        idx_j = f"IFERROR(INDEX({S}!$J${FIRST_DATA_ROW}:$J${LAST_DATA_ROW},{match_formula}),\"\")"
        idx_k = f"IFERROR(INDEX({S}!$K${FIRST_DATA_ROW}:$K${LAST_DATA_ROW},{match_formula}),\"\")"
        idx_l = f"IFERROR(INDEX({S}!$L${FIRST_DATA_ROW}:$L${LAST_DATA_ROW},{match_formula}),\"\")"
        idx_m = f"IFERROR(INDEX({S}!$M${FIRST_DATA_ROW}:$M${LAST_DATA_ROW},{match_formula}),\"\")"

        ws.cell(row=r, column=1, value=i)
        ws.cell(row=r, column=2, value=f"={S}!$G$3")
        ws.cell(row=r, column=3, value=f"={idx_j}")
        ws.cell(row=r, column=4, value=f"={idx_k}")
        ws.cell(row=r, column=5, value=f"={idx_l}")
        ws.cell(row=r, column=6, value=f"={idx_m}")
        ws.cell(row=r, column=7,
                value=(f'=IF(E{r}="","",IF(OR(E{r}<0.5,E{r}>1.5),"Danger",'
                       f'IF(OR(E{r}<0.8,E{r}>1.3),"Attention","OK")))'))
        link_cell = ws.cell(row=r, column=8, value="Ouvrir ➜")
        link_cell.hyperlink = f"#{quote_sheetname(sheet)}!A1"
        link_cell.font = Font(name=FONT_NAME, size=9, color="1F4E79", underline="single")
        link_cell.alignment = CENTER

        for col in range(1, 9):
            cell = ws.cell(row=r, column=col)
            cell.border = THIN_BORDER
            if col not in (2, 8):
                cell.alignment = CENTER
            cell.font = f_normal(size=10)
        ws.cell(row=r, column=3).number_format = "0.0"
        ws.cell(row=r, column=4).number_format = "0.0"
        ws.cell(row=r, column=5).number_format = "0.00"
        ws.cell(row=r, column=6).number_format = "0.0"
        if (i % 2) == 0:
            for col in range(1, 9):
                ws.cell(row=r, column=col).fill = fill(GREY_LIGHT)

    # Mise en forme conditionnelle colonne Alerte + ACWR synthèse
    alert_rng = f"G{synth_start}:G{synth_end}"
    ws.conditional_formatting.add(alert_rng, CellIsRule(
        operator="equal", formula=['"Danger"'], fill=fill(RED), font=Font(color=RED_TXT, bold=True)))
    ws.conditional_formatting.add(alert_rng, CellIsRule(
        operator="equal", formula=['"Attention"'], fill=fill(ORANGE), font=Font(color=ORANGE_TXT, bold=True)))
    ws.conditional_formatting.add(alert_rng, CellIsRule(
        operator="equal", formula=['"OK"'], fill=fill(GREEN), font=Font(color=GREEN_TXT, bold=True)))
    acwr_rng = f"E{synth_start}:E{synth_end}"
    ws.conditional_formatting.add(acwr_rng, FormulaRule(
        formula=[f'AND(E{synth_start}<>"",OR(E{synth_start}<0.5,E{synth_start}>1.5))'],
        fill=fill(RED), font=Font(color=RED_TXT, bold=True)))
    ws.conditional_formatting.add(acwr_rng, FormulaRule(
        formula=[f'AND(E{synth_start}<>"",OR(AND(E{synth_start}>=0.5,E{synth_start}<0.8),AND(E{synth_start}>1.3,E{synth_start}<=1.5)))'],
        fill=fill(ORANGE), font=Font(color=ORANGE_TXT, bold=True)))
    ws.conditional_formatting.add(acwr_rng, FormulaRule(
        formula=[f'AND(E{synth_start}<>"",E{synth_start}>=0.8,E{synth_start}<=1.3)'],
        fill=fill(GREEN), font=Font(color=GREEN_TXT, bold=True)))

    table = Table(displayName="TblSynthese", ref=f"A{synth_header_row}:H{synth_end}")
    table.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=False)
    ws.add_table(table)

    # -------- KPI (au-dessus de la synthèse) --------------------------------
    kpi_row = 5
    kpis = [
        ("NOMBRE D'ATHLÈTES", f"=COUNTA(B{synth_start}:B{synth_end})", "0"),
        ("CHARGE TOTALE GROUPE (7j)", f"=SUM(C{synth_start}:C{synth_end})", "0.0"),
        ("CHARGE MOYENNE (7j)", f"=IFERROR(AVERAGE(C{synth_start}:C{synth_end}),0)", "0.0"),
        ("ACWR MOYEN", f"=IFERROR(AVERAGE(E{synth_start}:E{synth_end}),0)", "0.00"),
        ("FATIGUE MOYENNE", f"=IFERROR(AVERAGE(F{synth_start}:F{synth_end}),0)", "0.0"),
        ("ATHLÈTES EN ALERTE", f'=COUNTIF(G{synth_start}:G{synth_end},"Danger")+COUNTIF(G{synth_start}:G{synth_end},"Attention")', "0"),
    ]
    col_start = 1
    box_w = 2  # colonnes par carte (2 colonnes fusionnées x N cartes = 12 -> fits A..N with margins)
    c = 1
    for label, formula, numfmt in kpis:
        col1 = get_column_letter(c)
        col2 = get_column_letter(c + 1)
        ws.merge_cells(f"{col1}{kpi_row}:{col2}{kpi_row}")
        lbl = ws[f"{col1}{kpi_row}"]
        lbl.value = label
        lbl.font = Font(name=FONT_NAME, size=9, bold=True, color=WHITE)
        lbl.fill = fill(NAVY_LIGHT)
        lbl.alignment = CENTER
        ws.row_dimensions[kpi_row].height = 16

        ws.merge_cells(f"{col1}{kpi_row+1}:{col2}{kpi_row+2}")
        val = ws[f"{col1}{kpi_row+1}"]
        val.value = formula
        val.number_format = numfmt
        val.font = Font(name=FONT_NAME, size=20, bold=True, color=NAVY)
        val.fill = fill(GREY_LIGHT)
        val.alignment = CENTER
        ws.row_dimensions[kpi_row+1].height = 28
        for rr in (kpi_row, kpi_row+1, kpi_row+2):
            for cc in (c, c+1):
                ws.cell(row=rr, column=cc).border = THIN_BORDER
        c += 2

    # Alerte visuelle sur la carte "Athlètes en alerte"
    alert_kpi_col = get_column_letter(kpis.index(kpis[-1]) * 2 + 1)
    ws.conditional_formatting.add(
        f"{alert_kpi_col}{kpi_row+1}:{get_column_letter(kpis.index(kpis[-1]) * 2 + 2)}{kpi_row+2}",
        FormulaRule(formula=[f"{alert_kpi_col}{kpi_row+1}>0"], fill=fill(RED), font=Font(color=RED_TXT, bold=True, size=20)))

    # -------- Boutons d'accès rapide -----------------------------------------
    nav_title_row = kpi_row + 4
    ws.merge_cells(f"A{nav_title_row}:N{nav_title_row}")
    nt = ws[f"A{nav_title_row}"]
    nt.value = "ACCÈS RAPIDE AUX FICHES ATHLÈTES"
    nt.font = f_normal(bold=True, size=11, color=NAVY)

    per_row = 10
    grid_row0 = nav_title_row + 1
    for i, sheet in enumerate(ATHLETE_SHEETS):
        rr = grid_row0 + i // per_row
        cc = 1 + (i % per_row)
        nav_button(ws, rr, cc, f"A{i+1}", sheet)
    ws.row_dimensions[grid_row0].height = 18

    grid_rows_used = -(-NB_ATHLETES // per_row)
    ws.merge_cells(f"A{grid_row0+grid_rows_used+1}:N{grid_row0+grid_rows_used+1}")
    hint = ws[f"A{grid_row0+grid_rows_used+1}"]
    hint.value = "Cliquer sur un numéro pour ouvrir la fiche de l'athlète correspondant."
    hint.font = f_normal(italic=True, size=9, color="7F7F7F")

    chart_row0 = grid_row0 + grid_rows_used + 3

    # -------- Graphique collectif CT (1 courbe / athlète) --------------------
    ch1 = LineChart()
    ch1.title = "Charge de Travail (CT) - toutes les athlètes"
    ch1.style = 10
    ch1.height = 9
    ch1.width = 24
    ch1.y_axis.title = "CT"
    ch1.x_axis.title = "Date"
    ch1.x_axis.number_format = "dd/mm"
    dates_ref = Reference(wb["Athlète 1"], min_col=1, min_row=FIRST_DATA_ROW, max_row=LAST_DATA_ROW)
    for sheet in ATHLETE_SHEETS:
        wsA = wb[sheet]
        data = Reference(wsA, min_col=9, min_row=HEADER_ROW, max_row=LAST_DATA_ROW)
        ch1.add_data(data, titles_from_data=True)
    ch1.set_categories(dates_ref)
    for s in ch1.series:
        s.graphicalProperties.line.width = 9000
    ch1.legend.position = "b"
    ws.add_chart(ch1, f"A{chart_row0}")

    # -------- Graphique collectif Fatigue (1 courbe / athlète) ---------------
    ch2 = LineChart()
    ch2.title = "Fatigue cumulée - toutes les athlètes"
    ch2.style = 10
    ch2.height = 9
    ch2.width = 24
    ch2.y_axis.title = "Fatigue"
    ch2.x_axis.title = "Date"
    ch2.x_axis.number_format = "dd/mm"
    for sheet in ATHLETE_SHEETS:
        wsA = wb[sheet]
        data = Reference(wsA, min_col=13, min_row=HEADER_ROW, max_row=LAST_DATA_ROW)
        ch2.add_data(data, titles_from_data=True)
    ch2.set_categories(dates_ref)
    for s in ch2.series:
        s.graphicalProperties.line.width = 9000
    ch2.legend.position = "b"
    ws.add_chart(ch2, f"A{chart_row0+19}")

    # -------- Graphique moyenne CT du groupe ---------------------------------
    ws_bdd = wb["Base de données"]
    bdd_last = base_start_row + NB_JOURS - 1
    dates_bdd = Reference(ws_bdd, min_col=1, min_row=base_start_row, max_row=bdd_last)

    ch3 = LineChart()
    ch3.title = "CT moyenne quotidienne du groupe"
    ch3.style = 12
    ch3.height = 9
    ch3.width = 24
    ch3.y_axis.title = "CT moyenne"
    ch3.x_axis.title = "Date"
    ch3.x_axis.number_format = "dd/mm"
    data3 = Reference(ws_bdd, min_col=2, min_row=3, max_row=bdd_last)
    ch3.add_data(data3, titles_from_data=True)
    ch3.set_categories(dates_bdd)
    ch3.series[0].graphicalProperties.line.width = 20000
    ch3.series[0].graphicalProperties.line.solidFill = "2E4E8C"
    ch3.legend = None
    ws.add_chart(ch3, f"P{chart_row0}")

    # -------- Graphique moyenne Fatigue du groupe -----------------------------
    ch4 = LineChart()
    ch4.title = "Fatigue moyenne quotidienne du groupe"
    ch4.style = 12
    ch4.height = 9
    ch4.width = 24
    ch4.y_axis.title = "Fatigue moyenne"
    ch4.x_axis.title = "Date"
    ch4.x_axis.number_format = "dd/mm"
    data4 = Reference(ws_bdd, min_col=3, min_row=3, max_row=bdd_last)
    ch4.add_data(data4, titles_from_data=True)
    ch4.set_categories(dates_bdd)
    ch4.series[0].graphicalProperties.line.width = 20000
    ch4.series[0].graphicalProperties.line.solidFill = "9BBB59"
    ch4.legend = None
    ws.add_chart(ch4, f"P{chart_row0+19}")

    widths = [8, 16, 15, 16, 8, 10, 10, 10, 8, 8, 8, 8, 8, 8]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = f"A{synth_header_row+1}"
    ws.sheet_view.zoomScale = 85

    ws.page_setup.orientation = "landscape"
    ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins = PageMargins(left=0.3, right=0.3, top=0.5, bottom=0.5, header=0.2, footer=0.2)
    ws.oddHeader.center.text = "Dashboard - Suivi de charge de l'effectif"
    ws.oddFooter.left.text = "&D"
    ws.oddFooter.right.text = "Page &P / &N"

    ws.protection.sheet = True
    for r in range(synth_start, synth_end + 1):
        pass  # cellules toutes verrouillées par défaut (lecture seule sur Dashboard)

    return ws

# ---------------------------------------------------------------------------
# ASSEMBLAGE
# ---------------------------------------------------------------------------
NAMES = [f"Athlète {i}" for i in range(1, NB_ATHLETES + 1)]

for i, name in enumerate(NAMES, start=1):
    build_athlete_sheet(wb, i, name)

build_parametres(wb)
ws_bdd, bdd_start_row = build_base_donnees(wb)
build_dashboard(wb, NAMES, bdd_start_row)

# Ordre des feuilles : Dashboard, Paramètres, Listes, Base de données, Athlètes...
order = ["Dashboard", "Paramètres", "Listes", "Base de données"] + ATHLETE_SHEETS
wb._sheets = [wb[n] for n in order]
for s in wb._sheets:
    s.sheet_view.tabSelected = False
wb["Dashboard"].sheet_view.tabSelected = True
wb.active = 0

wb.save(OUTPUT)
print(f"Fichier généré : {OUTPUT}")
