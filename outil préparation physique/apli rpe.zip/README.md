# ⚡ RPE Coach — Application de suivi de charge d'entraînement

## Fonctionnalités

### Interface Athlète
- Connexion et création de compte (nom saisi à la première connexion)
- Accueil : liste des séances **non évaluées uniquement** (aujourd'hui + séances passées non notées)
- Si tout est évalué : message "Aucune séance à évaluer"
- Saisie de la **durée** en minutes (convertie automatiquement en heures pour l'export)
- Évaluation **RPE 6–20** (échelle de Borg) avec :
  - Zone colorée dynamique (vert → rouge selon l'intensité)
  - 4 indicateurs physiologiques automatiques : sudation, douleur musculaire, respiration, fréquence cardiaque
  - Calcul de la charge en temps réel (RPE × durée en h)
- **Commentaire libre** + tags rapides
- Page de confirmation avec récapitulatif et mention de l'export Excel

### Interface Administrateur
- **Créer des séances** : nom, date, heure, durée, délai de rappel automatique
- **Gérer les séances** : liste avec statut (prévue, en cours, terminée)
- **Envoyer des rappels** :
  - 🔔 Rappel dans 30 min (envoyé uniquement aux athlètes n'ayant pas encore répondu)
  - 📲 Rappel immédiat (idem)
- **Résultats** : RPE moyen, charge moyenne, détail par athlète, liste des non-répondants
- **Mapping Excel** : choisir les colonnes (A, B, C…) et la ligne de départ
- **Export Excel** : un onglet par athlète, chaque ligne = une séance, trié par date

## Installation

### Prérequis
- Node.js 18+
- npm

### Lancement
```bash
cd rpe-app
npm install
node server.js
```

L'application démarre sur **http://localhost:3000**

### Première utilisation
1. Aller sur `http://localhost:3000/setup.html`
2. Créer le compte admin avec la clé : `RPE-ADMIN-SETUP`
3. Se connecter en tant qu'admin sur `/admin.html`
4. Les athlètes créent leur compte sur la page d'accueil `/`

## Structure des fichiers

```
rpe-app/
├── server.js          # Serveur Express (API)
├── db.js              # Base de données JSON locale
├── data.json          # Données (créé automatiquement)
├── package.json
└── public/
    ├── index.html     # Login / Inscription athlète
    ├── athlete.html   # Interface athlète
    ├── admin.html     # Interface administrateur
    ├── setup.html     # Création compte admin (1 seule fois)
    └── manifest.json  # PWA (installable sur mobile)
```

## Export Excel

### Fonctionnement
- Les données exportées : **date, durée (en heures), RPE, commentaire**
- La durée est automatiquement convertie : minutes → heures (ex : 75 min → 1.25 h)
- Un onglet par athlète, nommé avec son prénom et nom
- Les lignes sont triées par date croissante
- La ligne de départ et les colonnes sont configurables depuis l'app

### Exemple de mapping
| Donnée | Colonne |
|--------|---------|
| Date | A |
| Durée (h) | B |
| RPE | C |
| Commentaire | D |
| Première ligne de données | 2 |

## Déploiement en production

Pour une utilisation réelle avec push notifications, déployer sur :
- **Railway** (gratuit, simple) : `railway up`
- **Render** : connecter le dépôt GitHub
- **VPS** : avec PM2 pour garder le serveur actif

### Push Notifications réelles
Pour activer les vraies notifications mobiles, intégrer **Firebase Cloud Messaging (FCM)** :
1. Créer un projet Firebase
2. Ajouter les clés FCM dans `server.js`
3. Enregistrer le service worker dans `manifest.json`

## Notes techniques
- Base de données JSON locale (suffisant pour 10–30 athlètes)
- Authentification JWT
- Export XLSX via la bibliothèque `xlsx`
- PWA installable sur iOS et Android (sans store)
